const EventEmitter = require('EventEmitter');
let Event = new EventEmitter();

export default Event;
