// import this file for static CARD JSON FILE MAP
  let Obj = {
    default: require('../data/languages/card_en.json'),
    en: require('../data/languages/card_en.json'),
    de: require('../data/languages/card_de.json'),
    fr: require('../data/languages/card_fr.json')
  }
  export default Obj;
